import { useQuery } from "@tanstack/react-query";

interface StaffMember {
  id: number;
  name: string;
  role: string;
  roleLabel: string;
  description: string;
  avatar: string;
}

interface StaffMembersProps {
  extended?: boolean;
}

export default function StaffMembers({ extended = false }: StaffMembersProps) {
  const { data: apiStaffMembers = [] } = useQuery({
    queryKey: ['/api/staff'],
    queryFn: async () => {
      const response = await fetch('/api/staff');
      if (!response.ok) {
        throw new Error('Error cargando miembros del staff');
      }
      return response.json();
    }
  });

  // Datos de respaldo por si la API falla o está vacía
  const fallbackStaffMembers: StaffMember[] = [
    {
      id: 1,
      name: "LutorKing",
      role: "Fundador",
      roleLabel: "ADMIN",
      description: "Administrador principal y creador del servidor.",
      avatar: "https://mc-heads.net/avatar/MHF_Steve/100.png"
    },
    {
      id: 2,
      name: "MinecraftPro",
      role: "Moderador",
      roleLabel: "MOD",
      description: "Encargado de mantener el orden y ayudar a los jugadores.",
      avatar: "https://mc-heads.net/avatar/MHF_Alex/100.png"
    },
    {
      id: 3,
      name: "Crafteo",
      role: "Ayudante",
      roleLabel: "HELPER",
      description: "Asistente para nuevos jugadores y soporte general.",
      avatar: "https://mc-heads.net/avatar/DigMinecraft/100.png"
    },
    {
      id: 4,
      name: "PixelMaster",
      role: "Desarrollador",
      roleLabel: "DEV",
      description: "Creador de plugins y funcionalidades exclusivas.",
      avatar: "https://mc-heads.net/avatar/Notch/100.png"
    }
  ];

  // Usar datos de la API si están disponibles, de lo contrario usar los datos de respaldo
  const members = apiStaffMembers.length > 0 ? apiStaffMembers : fallbackStaffMembers;
  
  // Limitar a 4 en la página principal
  const displayMembers = extended ? members : members.slice(0, 4);

  const getBadgeColor = (roleLabel: string) => {
    switch (roleLabel) {
      case 'ADMIN': return 'bg-red-500';
      case 'MOD': return 'bg-purple-500';
      case 'HELPER': return 'bg-blue-500';
      case 'DEV': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  if (!extended) {
    return (
      <section id="staff" className="py-16 bg-gradient-to-b from-gray-900 to-primary">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-minecraft text-white mb-12 text-center">NUESTRO STAFF</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {displayMembers.map((member: StaffMember) => (
              <div key={member.id} className="bg-gray-800 rounded-lg p-6 text-center overflow-hidden pixel-border">
                <div className="relative w-24 h-24 mx-auto mb-4">
                  <img src={member.avatar} alt={member.name} className="rounded-lg" />
                  <div className={`absolute -top-1 -right-1 ${getBadgeColor(member.roleLabel)} text-xs text-white px-2 py-1 rounded-md`}>
                    {member.roleLabel}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-white mb-1">{member.name}</h3>
                <p className="text-gray-400 mb-3">{member.role}</p>
                <p className="text-gray-300 text-sm">{member.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {displayMembers.map((member: StaffMember) => (
        <div key={member.id} className="bg-gray-800 rounded-lg p-6 text-center overflow-hidden pixel-border">
          <div className="relative w-24 h-24 mx-auto mb-4">
            <img src={member.avatar} alt={member.name} className="rounded-lg" />
            <div className={`absolute -top-1 -right-1 ${getBadgeColor(member.roleLabel)} text-xs text-white px-2 py-1 rounded-md`}>
              {member.roleLabel}
            </div>
          </div>
          <h3 className="text-xl font-bold text-white mb-1">{member.name}</h3>
          <p className="text-gray-400 mb-3">{member.role}</p>
          <p className="text-gray-300 text-sm">{member.description}</p>
        </div>
      ))}
    </div>
  );
}